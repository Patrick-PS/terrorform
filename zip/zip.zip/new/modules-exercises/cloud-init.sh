#!/bin/bash

sudo apt -qq update
sudo apt -qq install -y apache2
sudo echo "Hello GURU user at `hostname`" > /var/www/html/index.html
